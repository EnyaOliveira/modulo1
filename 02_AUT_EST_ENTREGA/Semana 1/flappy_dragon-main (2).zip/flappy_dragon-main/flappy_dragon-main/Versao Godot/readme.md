Flappy Dragon - Versão Godot
============================

Esse é a versão em Godot do mesmo jogo. Serve para ver alternativas do mesmo
conceito e os mesmos objetos de programação.

Saiba mais sobre o Godot em: <https://godotengine.org/>

Há também um tutorial para iniciantes em Godot. Ver o arquivo Godot tutorial.pdf

 

 

 

 

 
